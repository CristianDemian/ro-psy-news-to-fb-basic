# RO Psy News → FB (basic)

Actor minimal care extrage știri RSS și generează 3 postări Facebook.
